﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using TaskManagementAPI.Models;
using TaskManagementAPI.Repositories;

namespace TaskManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private const string SecretKey = "your_very_secure_secret_key_12345"; 
        private readonly SymmetricSecurityKey _signingKey;

        public AuthController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
            _signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            if (user == null || !IsValidUsername(user.Username) || !IsValidPassword(user.Password))
            {
                return BadRequest("Invalid user data. Username must be 3-20 characters and password must meet complexity requirements.");
            }

            var existingUser = await _userRepository.GetUserAsync(user.Username);
            if (existingUser != null)
            {
                return BadRequest("User already exists.");
            }

            await _userRepository.AddUserAsync(user);
            return Ok("User registered successfully.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User user)
        {
            if (user == null || string.IsNullOrEmpty(user.Username) || string.IsNullOrEmpty(user.Password))
            {
                return BadRequest("Invalid login request.");
            }

            var existingUser = await _userRepository.GetUserAsync(user.Username);
            if (existingUser == null || existingUser.Password != user.Password)
            {
                return Unauthorized("Invalid username or password.");
            }

            var token = GenerateJwtToken(existingUser.Username);
            return Ok(new { Token = token, Username = existingUser.Username });
        }

        private string GenerateJwtToken(string username)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, username) }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private bool IsValidUsername(string username)
        {
            return !string.IsNullOrEmpty(username) && username.Length >= 3 && username.Length <= 20 &&
                   System.Text.RegularExpressions.Regex.IsMatch(username, @"^[a-zA-Z0-9_]+$");
        }

        private bool IsValidPassword(string password)
        {
            return !string.IsNullOrEmpty(password) && password.Length >= 8 &&
                   System.Text.RegularExpressions.Regex.IsMatch(password, @"[A-Z]") &&
                   System.Text.RegularExpressions.Regex.IsMatch(password, @"[a-z]") &&
                   System.Text.RegularExpressions.Regex.IsMatch(password, @"[0-9]") &&
                   System.Text.RegularExpressions.Regex.IsMatch(password, @"[\W_]");
        }
    }
}
