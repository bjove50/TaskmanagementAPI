﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.Models;
using TaskManagementAPI.Services;

namespace TaskManagementAPI.Controllers

{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly TaskService _taskService;

        public TasksController(TaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TaskItem>> GetTask(int id)
        {
            var task = await _taskService.GetTaskAsync(id);
            if (task == null) return NotFound();
            return Ok(task);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetAllTasks()
        {
            var tasks = await _taskService.GetAllTasksAsync();
            return Ok(tasks);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTask([FromBody] TaskItem task)
        {
            if (task == null || string.IsNullOrWhiteSpace(task.Title))
                return BadRequest("Task cannot be null and Title is required");

            await _taskService.AddTaskAsync(task);
            return CreatedAtAction(nameof(GetTask), new { id = task.Id }, task);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateTask([FromBody] TaskItem task)
        {
            if (task == null || task.Id == 0)
                return BadRequest("Task ID mismatch or Task is null");

            var taskExists = await _taskService.GetTaskAsync(task.Id);
            if (taskExists == null)
                return NotFound();

            await _taskService.UpdateTaskAsync(task);

            return Ok(task);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            var taskExists = await _taskService.GetTaskAsync(id);
            if (taskExists == null)
            {
                return NotFound(new { message = $"Task with ID {id} not found." });
            }

            await _taskService.DeleteTaskAsync(id);

            var allTasks = await _taskService.GetAllTasksAsync();

           
            return Ok(allTasks);
        }

    }
}
    


       