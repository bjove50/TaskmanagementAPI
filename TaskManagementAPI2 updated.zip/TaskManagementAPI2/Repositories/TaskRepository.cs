﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly List<TaskItem> _tasks = new();

        public TaskRepository()
        {
            
            _tasks.Add(new TaskItem
            {
                Id = 1,
                Title = "Alvin",
                Description = "GREATEST BOSS OF ALL TIME.",
                IsCompleted = false,
                CreatedAt = DateTime.Now,
                DueDate = DateTime.Now.AddDays(5),
                Priority = "High"
            });

            _tasks.Add(new TaskItem
            {
                Id = 2,
                Title = "Adrian",
                Description = "THE GOD FATHER",
                IsCompleted = true,
                CreatedAt = DateTime.Now.AddDays(-1),
                DueDate = DateTime.Now.AddDays(2),
                Priority = "Medium"
            });

            _tasks.Add(new TaskItem
            {
                Id = 3,
                Title = "Warren",
                Description = "THE SILENT GOD",
                IsCompleted = false,
                CreatedAt = DateTime.Now.AddDays(-2),
                DueDate = DateTime.Now.AddDays(3),
                Priority = "Low"
            });

            _tasks.Add(new TaskItem
            {
                Id = 4,
                Title = "Bryan",
                Description = "THE BRAVEMAN",
                IsCompleted = false,
                CreatedAt = DateTime.Now.AddDays(-3),
                DueDate = DateTime.Now.AddDays(7),
                Priority = "High"
            });

            _tasks.Add(new TaskItem
            {
                Id = 5,
                Title = "Shermel",
                Description = "MR NOBODY",
                IsCompleted = true,
                CreatedAt = DateTime.Now.AddDays(-5),
                DueDate = DateTime.Now.AddDays(1),
                Priority = "Medium"
            });

            _tasks.Add(new TaskItem
            {
                Id = 6,
                Title = "Kylo",
                Description = "THE BLACK SUPERMAN",
                IsCompleted = false,
                CreatedAt = DateTime.Now.AddDays(-1),
                DueDate = DateTime.Now.AddDays(4),
                Priority = "Low"
            });

            _tasks.Add(new TaskItem
            {
                Id = 7,
                Title = "Irish",
                Description = "THE PRETTYBOY",
                IsCompleted = false,
                CreatedAt = DateTime.Now.AddDays(-4),
                DueDate = DateTime.Now.AddDays(6),
                Priority = "High"
            });
        }

        public Task<TaskItem> GetTaskAsync(int id) => Task.FromResult(_tasks.Find(t => t.Id == id));
        public Task<IEnumerable<TaskItem>> GetAllTasksAsync() => Task.FromResult<IEnumerable<TaskItem>>(_tasks);
        public Task AddTaskAsync(TaskItem task)
        {
            _tasks.Add(task);
            return Task.CompletedTask;
        }

        public Task UpdateTaskAsync(TaskItem task)
        {
            var existingTask = _tasks.Find(t => t.Id == task.Id);
            if (existingTask != null)
            {
                existingTask.Title = task.Title;
                existingTask.Description = task.Description;
                existingTask.IsCompleted = task.IsCompleted;
                existingTask.DueDate = task.DueDate;
                existingTask.Priority = task.Priority;
            }
            return Task.CompletedTask;
        }

        public Task DeleteTaskAsync(int id)
        {
            var task = _tasks.Find(t => t.Id == id);
            if (task != null)
            {
                _tasks.Remove(task);
            }
            return Task.CompletedTask;
        }
    }
}
