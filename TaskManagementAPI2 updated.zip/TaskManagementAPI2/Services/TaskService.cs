﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagementAPI.Models;
using TaskManagementAPI.Repositories;

namespace TaskManagementAPI.Services
{
    public class TaskService
    {
        private readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository) => _taskRepository = taskRepository;

        public Task<TaskItem> GetTaskAsync(int id) => _taskRepository.GetTaskAsync(id);
        public Task<IEnumerable<TaskItem>> GetAllTasksAsync() => _taskRepository.GetAllTasksAsync();
        public Task AddTaskAsync(TaskItem task) => _taskRepository.AddTaskAsync(task);
        public Task UpdateTaskAsync(TaskItem task) => _taskRepository.UpdateTaskAsync(task);
        public Task DeleteTaskAsync(int id) => _taskRepository.DeleteTaskAsync(id);
    }
}
